const amqp = require("amqplib/callback_api");

const uri = `amqp://client:1234@localhost:5672/demo01`;
const EXCHANGE = "notifications";

amqp.connect(uri, (err, conn) => {
  conn.createChannel((err2, channel) => {
    channel.assertExchange(EXCHANGE, "fanout", { durable: false });

    channel.assertQueue("", { exclusive: true }, (err3, q) => {
      channel.bindQueue(q.queue, EXCHANGE, "");

      console.log("👀 DisplayService: waiting for messages...");

      channel.consume(q.queue, msg => {
        const data = JSON.parse(msg.content.toString());
        console.log(`🌡️ Temperature = ${data.temperature}°C at ${data.timestamp}`);
      }, { noAck: true });
    });
  });
});