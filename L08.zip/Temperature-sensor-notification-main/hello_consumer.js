const amqp = require('amqplib/callback_api');

// การกำหนดค่าการเชื่อมต่อ
const USERNAME = "client";
const PASSWORD = "1234";
const HOST = "localhost";
const PORT = "5672";
const VHOST = "demo01"; 
const EXCHANGE = "logs"; // ใช้ Exchange ไม่ใช่ Queue แล้ว

// สร้าง URI สำหรับเชื่อมต่อ RabbitMQ
const uri = `amqp://${USERNAME}:${PASSWORD}@${HOST}:${PORT}/${VHOST}`;

amqp.connect(uri, (error0, connection) => {
    if (error0) {
        console.log(error0);
        throw error0;
    }

    connection.createChannel((error1, channel) => {
        if (error1) {
            console.log(error1);
            throw error1;
        }

        // สร้าง Exchange แบบ fanout
        channel.assertExchange(EXCHANGE, 'fanout', {
            durable: false
        });

        // ให้ RabbitMQ สร้าง queue ชั่วคราวเอง
        channel.assertQueue('', {
            exclusive: true
        }, (error2, q) => {
            if (error2) {
                console.log(error2);
                throw error2;
            }

            console.log(` [*] Waiting for messages in ${q.queue}. To exit press CTRL+C`);

            // ผูก queue ที่เพิ่งสร้างกับ exchange
            channel.bindQueue(q.queue, EXCHANGE, '');

            // รับข้อความ
            channel.consume(q.queue, (msg) => {
                console.log(` [x] Received ${msg.content.toString()}`);
            }, {
                noAck: true // ไม่ต้อง ack
            });
        });
    });
});