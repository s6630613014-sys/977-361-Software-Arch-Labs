const amqp = require('amqplib/callback_api');

// การกำหนดค่าการเชื่อมต่อ (ตามเอกสารหน้า 25)
const USERNAME = "client"
const PASSWORD = "1234"
const HOST = "localhost"
const PORT = "5672"
const VHOST = "demo01" // Virtual Host ที่สร้างไว้
const QUEUE = "hello" // ชื่อคิว
const EXCHANGE = "logs"

// สร้างข้อความที่จะส่ง พร้อมประทับเวลา
const MESSAGE = `Hello World!! @${new Date().toLocaleTimeString()}` 

// สร้าง URI สำหรับเชื่อมต่อ RabbitMQ
const uri = `amqp://${USERNAME}:${PASSWORD}@${HOST}:${PORT}/${VHOST}`

amqp.connect(uri, (error0, connection) => {
    // จัดการข้อผิดพลาดในการเชื่อมต่อ
    if (error0) {
        throw error0;
    }
    
    // สร้าง Channel (ช่องทางสื่อสาร)
    connection.createChannel((error1, channel) => {
        if (error1) {
            throw error1;
        }

        // ยืนยันว่า Queue ชื่อ 'hello' มีอยู่
        channel.assertQueue(EXCHANGE, {
            durable: false
        });

        channel.assertExchange(EXCHANGE, 'fanout', {
            durable: false
       });
        channel.publish(EXCHANGE, '', Buffer.from(MESSAGE));

        console.log(` [x] Sent ${MESSAGE}`);
    });

    // หน่วงเวลาเล็กน้อยก่อนปิดการเชื่อมต่อ
    setTimeout(function() {
        connection.close();
        process.exit(0);
    }, 500);
});