const fs = require("fs");
const amqp = require("amqplib/callback_api");

const uri = `amqp://client:1234@localhost:5672/demo01`;
const EXCHANGE = "notifications";

amqp.connect(uri, (err, conn) => {
  conn.createChannel((err2, channel) => {
    channel.assertExchange(EXCHANGE, "fanout", { durable: false });

    channel.assertQueue("", { exclusive: true }, (err3, q) => {
      channel.bindQueue(q.queue, EXCHANGE, "");

      console.log("📝 LogService: waiting and logging to log.txt...");

      channel.consume(q.queue, msg => {
        fs.appendFileSync("log.txt", msg.content.toString() + "\n");
        console.log("✅ Logged");
      }, { noAck: true });
    });
  });
});