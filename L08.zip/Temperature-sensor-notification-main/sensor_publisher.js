const amqp = require("amqplib/callback_api");

const USERNAME = "client";
const PASSWORD = "1234";
const HOST = "localhost";
const PORT = "5672";
const VHOST = "demo01";
const EXCHANGE = "notifications";

const uri = `amqp://${USERNAME}:${PASSWORD}@${HOST}:${PORT}/${VHOST}`;

function sendSensorData() {
  const data = {
    sensor_id: "s01",
    temperature: (Math.random() * 10 + 30).toFixed(2), // random 30 - 40
    timestamp: new Date().toISOString()
  };

  amqp.connect(uri, (err, conn) => {
    conn.createChannel((err2, channel) => {
      channel.assertExchange(EXCHANGE, "fanout", { durable: false });
      channel.publish(EXCHANGE, "", Buffer.from(JSON.stringify(data)));
      console.log("📤 Sent:", data);
    });
    setTimeout(() => conn.close(), 500);
  });
}

// ส่งทุก 3 วินาที
setInterval(sendSensorData, 3000);